/**
 *
 *  @author Leontiev Andrii S17025
 *
 */

package zad3;


public class Time {
}
